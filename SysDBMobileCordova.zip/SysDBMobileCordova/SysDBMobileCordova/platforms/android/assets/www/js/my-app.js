// Export selectors engine
var $$ = Dom7;
var iRecordCount = 0;

// Initialize your app
var myApp = new Framework7({
    modalTitle: 'SYSDB',
    animateNavBackIcon: false,
    preloadPreviousPage: false
});

// Add main View
var mainView = myApp.addView('.view-main', {
    // Enable dynamic Navbar
    dynamicNavbar: true,
});

//=== Urls
var BaseURLWeb = "http://voisysdbdev/SysDB.Api/api/DeviceManagement/"; // web dev
//var BaseURLApp = "https://sysdbapidev.voith.net/DeviceManagement/"; //mobile dev
var BaseURLApp = "https://sysdbapi.voith.net/DeviceManagement/"; //mobile prod

//https://sysdbapidev.voith.net/DeviceManagement/Getdevices?pattern={YourSearchPattern} 
//https://sysdbapidev.voith.net/DeviceManagement/GetDeviceTabInfos?deviceId={YourDeviceId}&tabId={YourTabId} 


var ENV = "WEB"; //Switch between mobile app and web app (Set for web:WEB and mobile:APP)

if (ENV != "APP" && (myApp.device.iphone || myApp.device.ipad || myApp.device.android)) {
    ENV = "APP";
}

if (ENV == "WEB") {
    BaseURLApp = BaseURLWeb;
}

/*
Local Store Keys
*/
var SYSDB_KEY = new Object();
SYSDB_KEY.SearchPattern = "";
SYSDB_KEY.DeviceID_TabID = "";

function checkConnection() {
    var status = false;
    if (ENV === "APP") {
        var networkState = navigator.connection.type;
        if (networkState !== undefined) {
            var states = {};
            states[Connection.UNKNOWN] = 'Unknown connection';
            states[Connection.ETHERNET] = 'Ethernet connection';
            states[Connection.WIFI] = 'WiFi connection';
            states[Connection.CELL_2G] = 'Cell 2G connection';
            states[Connection.CELL_3G] = 'Cell 3G connection';
            states[Connection.CELL_4G] = 'Cell 4G connection';
            states[Connection.CELL] = 'Cell generic connection';
            states[Connection.NONE] = 'No network connection';

            //alert('Connection type: ' + states[networkState]);

            if (states[networkState].indexOf("WiFi") != -1 || states[networkState].indexOf("Cell") != -1)
                status = true;
            else
                status = false;
        }
        else
            status = false;
    } else {
        if (navigator.onLine)
            status = true;
        else
            status = false;
    }
    return status;
}

function GetDataAndRender(urlAddress, fnRenderData, Args, sLocalStoreKey) {
    myApp.showIndicator();
    if (1 || checkConnection() === true) {
        $.ajax({
            url: urlAddress,
            type: "GET",
            dataType: 'json',
            success: function (result) {
                //alert("Ajax call : " + result);
                if (sLocalStoreKey != null)
                    localStorage.setItem(sLocalStoreKey, JSON.stringify(result));
                fnRenderData(result, Args);
                myApp.hideIndicator();
            },
            error: function (xhr, status, error) {
                myApp.hideIndicator();

                if (xhr.status === 401 || xhr.status === 0) {
                    myApp.alert("Authentication failed");
                }
                else if (checkConnection() === false) {
                    myApp.alert("Network is not available.");
                } else {
                    myApp.alert("Invalid search pattern.");
                }
            }
        });
    } else {
        myApp.hideIndicator();
        myApp.alert("Network is not available.");
    }
}

function getParmFromUrl(url, parm) {
    var re = new RegExp(".*[?&]" + parm + "=([^&]+)(&|$)");
    var match = url.match(re);
    return (match ? match[1] : "");
}

// Callbacks for specific pages when it initialized
/* ===== Modals Page events  ===== */
if (ENV == 'WEB') {
    $$('.visible-in-web').removeClass('visible-in-web');
    $$('.app-title').css('left', '10px');
    myApp.onPageInit('index', function () {
    }).trigger();
} else {
    myApp.onPageInit('index', function () {
    }).trigger();
}

// In page events:
$$(document).on('pageInit', function (e) {
    myApp.closeNotification(".notification-item");
    // Page Data contains all required information about loaded and initialized page 
    var page = e.detail.page;
    switch (page.name) {
        case "DeviceTabs":
            var deviceId = getParmFromUrl(page.url, "ID");
            var deviceName = getParmFromUrl(page.url, "Name");
            var description = getParmFromUrl(page.url, "desc");
            $$("#divNavbarTitle").html(deviceName + ' : ' + description);
            GetDeviceTabs(deviceName, deviceId);
            break;
        case "DeviceTabDetails":
            var deviceID = getParmFromUrl(page.url, "deviceID");
            var tabID = getParmFromUrl(page.url, "tabID");
            var tabName = getParmFromUrl(page.url, "tabName");
            var deviceName = getParmFromUrl(page.url, "deviceName");
            $$("#divNavbarDeviceTabDetail").html(deviceName + ' : ' + tabName);
            GetDeviceInfo(deviceID, tabID);
            break;
        case "DeviceSummary":
            var pattern = getParmFromUrl(page.url, "pattern");
            GetDevices(pattern);

            if (iRecordCount >= 50) {
                $$(".Notification").html('Too many search results; first 50 shown.');
            }
            else {
                $$(".Notification").remove();
            }
            break;
    }
})

$$(document).on('click', '#deviceSearch', function () {
    var search = $$('#idSearch')[0].value;
    if (search !== '') {
        localStorage.clear();
        iRecordCount = 0;
        SYSDB_KEY.SearchPattern = "SYSDB_KEY_" + search;
        var urlString = BaseURLApp + 'Getdevices?pattern=' + encodeURIComponent(search);
        GetDataAndRender(urlString, RenderDevicePage, search, SYSDB_KEY.SearchPattern);
    }
});

function RenderDevicePage(data, pattern) {
    var id = 0;
    var name = "";
    var description = "";
    iRecordCount = Object.keys(data).length;

    if (iRecordCount === 0) {
        myApp.alert("No device found");
    } else
        if (iRecordCount === 1) {
            id = data[Object.keys(data)]["Id"];
            name = data[Object.keys(data)]["Name"];
            description = data[Object.keys(data)]["Description"];
            mainView.router.loadPage("DeviceTabs.html?ID=" + id + '&Name=' + name + '&desc=' + description);
        } else {
            mainView.router.loadPage("DeviceSummary.html?pattern=" + pattern);
        }
}

function getStoredData(StorageKey) {
    var StoredData = localStorage.getItem(StorageKey);
    if (StoredData != null && StoredData != "")
        return JSON.parse(StoredData);
    else
        return null;
}

function GetDevices(pattern) {
    var data = getStoredData(SYSDB_KEY.SearchPattern);
    if (data === null) {
        var urlString = BaseURLApp + 'Getdevices?pattern=' + pattern;
        GetDataAndRender(urlString, RenderDevices, null, null);
    } else {
        RenderDevices(data);
    }
}

function RenderDevices(data) {
    var strHtml = '';
    strHtml += '    <div class="content-block-inner Notification NotificationCSS"></div>';
    $$.each(data, function (i) {        
        strHtml += '<li><a href="DeviceTabs.html?ID=' + data[i]["Id"] + '&Name=' + data[i]["Name"] + '&desc=' + data[i]["Description"] + '" class="item-link">';
        strHtml += '<div class="item-content">';
        strHtml += '    <div class="item-inner">'
        strHtml += '        <div class="item-title-row">'
        strHtml += '            <div class="item-title">' + data[i]["Name"] + '</div>';
        strHtml += '        </div>';
        strHtml += '        <div class="item-subtitle">' + data[i]["LANSite"] + ' | ' + data[i]["ITOrganisation"] + ' | ' + data[i]["LastChange"] + '</div>';
        strHtml += '        <div class="item-after">' + data[i]["Description"];
        strHtml += '        </div>';
        strHtml += '    </div>';
        strHtml += '</div>';
        strHtml += '</a></li>';
    });

    $$("#ulDevices").html(strHtml);
}

function GetDeviceTabs(deviceName, deviceID) {
    var data = getStoredData(SYSDB_KEY.SearchPattern);
    if (data === null) {
        var urlString = BaseURLApp + 'Getdevices?pattern=' + deviceName;
        GetDataAndRender(urlString, RenderDeviceTabs, deviceID, null);
    } else {
        RenderDeviceTabs(data, deviceID)
    }
}

function RenderDeviceTabs(data, deviceID) {
    var strHtml = '';
    $$.each(data[deviceID]["DeviceTabs"], function (j) {
        strHtml += '<li>';
        strHtml += ' <a href="DeviceTabDetails.html?deviceID=' + data[deviceID]["Id"] + '&tabID=' + data[deviceID]["DeviceTabs"][j]["Id"] + "&deviceName=" + data[deviceID]["Name"] + "&tabName=" + data[deviceID]["DeviceTabs"][j]["Name"] + '" class="item-content item-link">';
        strHtml += '<div class="item-inner">'
        strHtml += '<div class="item-title">' + data[deviceID]["DeviceTabs"][j]["Name"] + '</div>';
        strHtml += '</div></a>';
        strHtml += '</li>'
    });
    $$("#ulDeviceTabs").html(strHtml);
}

function GetDeviceInfo(deviceID, tabID) {
    SYSDB_KEY.DeviceID_TabID = "SYSDB_DEVICEID_TABID_" + deviceID + "_" + tabID;
    var data = getStoredData(SYSDB_KEY.DeviceID_TabID);
    if (data === null) {
        var urlString = BaseURLApp + 'GetDeviceTabInfos?deviceId=' + deviceID + '&tabId=' + tabID;
        GetDataAndRender(urlString, RenderDeviceInfo, null, SYSDB_KEY.DeviceID_TabID);
    } else {
        RenderDeviceInfo(data);
    }
}

function RenderDeviceInfo(data) {
    var strHtml = '';
    $$.each(data, function (i) {
        var obj = data[i];
        $$.each(obj["Groups"], function (j) {
            strHtml += '<li class="accordion-item">';
            strHtml += ' <a href="#" class="item-content item-link">';
            strHtml += '<div class="item-inner">'
            strHtml += '<div class="item-title">' + obj["Groups"][j]["Name"] + '</div>';
            strHtml += '</div></a>';
            if (obj["Groups"][j]["Id"] === 13) {
                strHtml += '<div class="accordion-item-content">';
                strHtml += '<div class="data-table">'
                strHtml += '<table>'
                strHtml += '<thead>'
                strHtml += '<tr>'
                strHtml += '<th class="label-cell">Description</th>'
                strHtml += '<th class="label-cell">Drive</th>'
                strHtml += '<th class="label-cell">FileSystem</th>'
                strHtml += '<th class="numeric-cell">Size</th>'
                strHtml += '</tr>'
                strHtml += '</thead>'
                strHtml += '<tbody>'
            }
            $$.each(obj["Groups"][j]["GroupFields"], function (k) {
                var objIterate = obj["Groups"][j]["GroupFields"][k];
                if (obj["Groups"][j]["Id"] === 13) {
                    strHtml += '<tr>'
                    strHtml += '<td class="label-cell">' + objIterate["Description"] + '</td>'
                    strHtml += '<td class="label-cell">' + objIterate["Drive"] + '</td>'
                    strHtml += '<td class="label-cell">' + objIterate["FileSystem"] + '</td>'
                    strHtml += '<td class="numeric-cell">' + objIterate["Size"] + '</td>'
                    strHtml += '</tr>'
                } else {
                    strHtml += '<div class="accordion-item-content">';
                    strHtml += '<div class="list-block">';
                    strHtml += '<ul>';
                    strHtml += '<li>';
                    strHtml += '<div class="item-content">';
                    strHtml += '<div class="item-inner">';
                    strHtml += '<div class="item-subtitle">' + objIterate["Name"] + '</div>'
                    strHtml += '<div class="item-after">' + objIterate["Value"] + '</div>'
                    strHtml += '</div>';
                    strHtml += '</div>';
                    strHtml += '</li>';
                    strHtml += '</ul>';
                    strHtml += '</div>';
                    strHtml += '</div>';
                }
            });
            if (obj["Groups"][j]["Id"] === 13) {
                strHtml += '</tbody>'
                strHtml += '</table>'
                strHtml += '</div>';
                strHtml += '</div>'
            }
            strHtml += '</li>'
        });
    });
    $$("#ulDeviceTabDetails").html(strHtml);
}

function OpenHomePage() {
    mainView.router.loadPage("index.html");
}