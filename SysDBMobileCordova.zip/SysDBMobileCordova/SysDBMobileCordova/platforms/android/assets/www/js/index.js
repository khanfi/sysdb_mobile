var app = {
    // Application Constructor
    initialize: function () {
        this.bindEvents();
    },
    // Bind Event Listeners
    //
    // Bind any events that are required on startup. Common events are:
    // 'load', 'deviceready', 'offline', and 'online'.
    bindEvents: function () {
        document.addEventListener('deviceready', this.onDeviceReady, false);
        document.addEventListener("online", this.onOnline, false);
        document.addEventListener("offline", this.onOffline, false);
    },
    // deviceready Event Handler
    //
    // The scope of 'this' is the event. In order to call the 'receivedEvent'
    // function, we must explicitly call 'app.receivedEvent(...);'
    onDeviceReady: function () {
        //alert("deviceready");

        var success = function (message) {
             //alert("Success:" + message);
        }

        var failure = function (error) {
            alert("Error:" + error);
        }
       
        //clientCertificate.registerAuthenticationCertificate("zzHDHSysDB_MobileApp.p12", "483268526080", success, failure);
        clientCertificate.register("zzHDHSysDB_MobileApp.p12", "483268526080", success, failure);
    },
    onOnline: function () {
        //alert("online");
    },
    onOffline: function () {
        //alert("offline");
    }
};


